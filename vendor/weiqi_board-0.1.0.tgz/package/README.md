# weiqi_board

A framework-independent Go board with immediate local placement, mouse input, and host reconciliation. The board renders 9×9, 13×13, or 19×19 intersections using a canvas background and reusable DOM stones.

## Development

```sh
npm install
npm run build
npm test
npm run lint
npm run lint:fix
npm run format
npm run format:check
```

Oxlint checks TypeScript and JavaScript, including scripts and tests. `lint` fails on errors or warnings; `lint:fix` applies available automatic fixes. Prettier formats source, styles, tests, documentation, and configuration using two spaces, single quotes, and no semicolons. Generated build output, dependencies, and the npm lockfile are excluded. Run `npm run lint` and `npm run format:check` for read-only checks before merging. Type checking remains part of `npm run build`.

## Package distribution

Run `npm ci`, `npm test`, and `npm pack` to produce a standalone, versioned
`weiqi_board-<version>.tgz`. Packing automatically builds the JavaScript,
TypeScript declarations, stylesheet, and texture assets. Consumers install this
archive with npm and import `weiqi_board`; they do not need the source checkout
or its development dependencies. Increment the package version for new releases.

`weiqi-app` keeps its selected release in its own `vendor/` directory. Updating
board source does not change the app until a new archive is explicitly installed.

## Placement flow


```text
Primary mouse click
→ board checks input permissions, turn, bounds, occupancy, and supplied destinations
→ board adds the stone, updates last move and turn, and commits DOM changes
→ onPlace(point, color, { premove })
→ host controller asks its rules engine to verify
→ host corrects the position only when necessary
```

The board does not implement captures, suicide, or ko. The host can remove captured stones or roll back a rejection with `set()`. Configuration and reconciliation never emit `onPlace` or automatically change the supplied turn. The callback runs synchronously after state and DOM changes; it does not wait for a browser paint.

```ts
import { WeiqiBoard } from 'weiqi_board'
import 'weiqi_board/style.css'

const board = WeiqiBoard(host, {
  boardSize: 19,
  movable: { color: 'both', free: true },
  premovable: { enabled: false },
  onPlace(point, color, metadata) {
    // This board already contains the stone and has switched the turn.
    controller.play(point, color, board)
  },
})
```

The sample controller is supplied by the integrating application. The current `weiqi-app` controller verifies through WASM, compares the authoritative position to `board.getState()`, and calls `set()` only for differences.

## Permissions and state

- `movable.color`: `'black'`, `'white'`, or `'both'` (default). Explicit `undefined` disables placement. With both colors enabled, the stone color follows `turnColor`.
- `movable.free`: defaults to `true`. It bypasses destination restrictions, while bounds, occupancy, turn, color, and `readOnly` remain enforced.
- `movable.dests`: `ReadonlyMap<StoneColor, readonly Intersection[]>`. Origins represent the black/white stone supplies, rather than existing stones. With `free: false`, an absent or empty list permits no placements.
- Successful local placements clear stale destination maps; the host supplies fresh destinations when ready.
- `stones`, `turnColor`, and `lastMove` can be supplied to initialize or reconcile the position. `lastMove: null` clears the marker, including after a pass.
- `set()` preserves omitted fields, merges provided permission/premove fields, and replaces supplied arrays and destination maps. Inputs and `getState()` snapshots are independently cloned. Callbacks are excluded from snapshots.
- Defaults are an empty 19×19 kaya board, polished stones, black turn, free placement by both colors, and enabled premoves.
- `onSelect` reports the mouse hover intersection. Keyboard, touch, pen, and secondary-button placement are unsupported.

## Premoves

```ts
board.set({
  movable: { color: 'black', free: false },
  premovable: {
    enabled: true,
    events: {
      set(point, color) {
        /* queued; no stone has been placed */
      },
      unset() {
        /* queue consumed or cancelled */
      },
    },
  },
})

// After the opponent's move, refresh position, turn, and legal destinations.
board.set({
  stones: authoritativeStones,
  turnColor: 'black',
  movable: { dests: new Map([['black', legalBlackIntersections]]) },
})
const placed = board.playPremove()
board.cancelPremove()
```

During the opponent's turn, a mouse click queues one empty intersection for the configured player color. Another point replaces the queue; clicking the same point cancels it. Queueing does not change stones, turn, or last move and ignores destination restrictions until execution.

`playPremove()` checks current permissions, occupancy, turn, and destinations, consumes the queue whether successful or not, and returns whether a local placement occurred. The return value does not represent later ruleset approval. Success emits `onPlace` with `premove: true` using the normal flow. `set()` never automatically executes a queue.

Disabling premoves, entering read-only mode, changing movable color or board size, and destroying the board clear the queue. Predrops and relocation of existing stones are not implemented.

## Rendering and lifecycle

Only the background uses a full-board canvas. Stone nodes are keyed by intersection; surviving nodes remain in place during additions, captures, and position correction. Transparent stone images are generated for the active style, CSS size, color, and pixel density, and reused for placement and previews. A normal placement does not redraw the background or regenerate material images.

`redraw()` refreshes presentation after external layout changes. `destroy()` removes owned DOM, observers, listeners, and queued state. The canvas drawing primitives, geometry helpers, themes, and texture cache remain available for decorative scenes and previews.

## Source organization

- [`src/board/`](src/board/createBoard.ts) owns configuration, placement permissions, input, lifecycle, and board presentation.
- [`src/geometry.ts`](src/geometry.ts) and [`src/geometry.constants.ts`](src/geometry.constants.ts) provide shared intersection helpers, hit testing, and geometry presets used by board interaction and rendering.
- [`src/materials/`](src/materials/boardThemes.ts) defines wood themes and stone styles.
- [`src/rendering/`](src/rendering/stoneRenderer.ts) contains keyed DOM stones, standalone drawing primitives, canvas sizing, and texture loading.
- [`src/types.ts`](src/types.ts) contains shared contracts; [`src/index.ts`](src/index.ts) preserves the public package interface.

Internal modules import their dependencies directly. Geometry is shared by the board and rendering; it does not depend on the board controller. Go legality and the React adapter remain owned by the host application.

## Verification

Build this package with `npm run build`, or run `npm test` to build and check configuration and package exports/assets. From `../weiqi-app`, run `npm run test:board` for browser verification, `npm run build` for the production application, and `npm run lint`. Browser tests use installed Google Chrome and include desktop and DPR 2 projects.
